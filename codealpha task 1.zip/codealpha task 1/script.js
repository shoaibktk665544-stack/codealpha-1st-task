let images=[
"https://images.unsplash.com/photo-1501785888041-af3ef285b470",
"https://images.unsplash.com/photo-1500530855697-b586d89ba3ee",
"https://images.unsplash.com/photo-1492144534655-ae79c964c9d7",
"https://images.unsplash.com/photo-1503376780353-7e6692767b70"
];

let currentIndex=0;

window.onload=function(){
document.getElementById("loader").style.display="none";
}

function toggleMode(){
document.body.classList.toggle("light");
}

function openLightbox(index){
document.getElementById("lightbox").style.display="flex";
currentIndex=index;
showImage();
}

function closeLightbox(){
document.getElementById("lightbox").style.display="none";
}

function changeImage(step){
currentIndex+=step;
if(currentIndex<0) currentIndex=images.length-1;
if(currentIndex>=images.length) currentIndex=0;
showImage();
}

function showImage(){
document.getElementById("lightbox-img").src=images[currentIndex];
}

function filterImages(category){
let imgs=document.querySelectorAll(".gallery img");
imgs.forEach(img=>{
if(category==="all"||img.dataset.category===category){
img.style.display="block";
}else{
img.style.display="none";
}
});
}

function searchImages(){
let value=document.getElementById("search").value.toLowerCase();
let imgs=document.querySelectorAll(".gallery img");

imgs.forEach(img=>{
let cat=img.dataset.category.toLowerCase();
if(cat.includes(value)){
img.style.display="block";
}else{
img.style.display="none";
}
});
}
